// LocalStorage, API key, demo mode, and toast helpers
function getInterests() {
  return JSON.parse(
    localStorage.getItem("vr_interests") || JSON.stringify(defaultInterests),
  );
}

function setInterests(v) {
  localStorage.setItem("vr_interests", JSON.stringify(v));
}
const countries = {
  KR: "한국",
  US: "미국",
  JP: "일본",
  GB: "영국",
  GLOBAL: "글로벌",
};
const demoVideos = [
  {
    id: "d1",
    title: "군인을 본 아기가 갑자기 경례를 했다",
    channel: "Tiny Moment",
    subs: 8200,
    views: 690000,
    avg: 21000,
    hours: 9,
    likes: 41000,
    comments: 1800,
    duration: 34,
    country: "KR",
    cat: "감동",
    thumb: "https://i.ytimg.com/vi/aqz-KE-bpKQ/hqdefault.jpg",
  },
  {
    id: "d2",
    title: "잘생긴 남자 때문에 하루 세끼 맥날 먹은 썰",
    channel: "Story Shorts",
    subs: 17000,
    views: 1180000,
    avg: 54000,
    hours: 14,
    likes: 72000,
    comments: 3100,
    duration: 52,
    country: "KR",
    cat: "웃긴 쇼츠",
    thumb: "https://i.ytimg.com/vi/tgbNymZ7vqY/hqdefault.jpg",
  },
  {
    id: "d3",
    title: "강아지가 원반 잡는 순간 모두가 소리쳤다",
    channel: "Dog Hero",
    subs: 2400,
    views: 310000,
    avg: 6200,
    hours: 7,
    likes: 22000,
    comments: 920,
    duration: 24,
    country: "KR",
    cat: "동물",
    thumb: "https://i.ytimg.com/vi/jNQXAC9IVRw/hqdefault.jpg",
  },
  {
    id: "d4",
    title: "I tried this AI video trick for 7 days",
    channel: "AI Creator Lab",
    subs: 56000,
    views: 940000,
    avg: 120000,
    hours: 21,
    likes: 38000,
    comments: 1400,
    duration: 480,
    country: "US",
    cat: "AI",
    thumb: "https://i.ytimg.com/vi/M7lc1UVf-VE/hqdefault.jpg",
  },
  {
    id: "d5",
    title: "엄마가 체조를 시켰더니 아기 표정이...",
    channel: "Baby Clip",
    subs: 3900,
    views: 430000,
    avg: 9000,
    hours: 11,
    likes: 26000,
    comments: 760,
    duration: 29,
    country: "KR",
    cat: "육아",
    thumb: "https://i.ytimg.com/vi/ScMzIvxBSi4/hqdefault.jpg",
  },
  {
    id: "d6",
    title: "Nobody expected this football dad training at home",
    channel: "Family Sports",
    subs: 12500,
    views: 870000,
    avg: 35000,
    hours: 18,
    likes: 51000,
    comments: 2100,
    duration: 41,
    country: "US",
    cat: "스포츠",
    thumb: "https://i.ytimg.com/vi/e-ORhEE9VVg/hqdefault.jpg",
  },
  {
    id: "d7",
    title: "일산 운동 전 먹기 좋은 밥집 TOP 5",
    channel: "Local Food",
    subs: 9800,
    views: 122000,
    avg: 17000,
    hours: 30,
    likes: 5400,
    comments: 320,
    duration: 610,
    country: "KR",
    cat: "맛집",
    thumb: "https://i.ytimg.com/vi/ysz5S6PUM-U/hqdefault.jpg",
  },
  {
    id: "d8",
    title: "月5万円で始めるインデックス投資",
    channel: "Money JP",
    subs: 41000,
    views: 520000,
    avg: 76000,
    hours: 27,
    likes: 18000,
    comments: 1100,
    duration: 720,
    country: "JP",
    cat: "경제",
    thumb: "https://i.ytimg.com/vi/kJQP7kiw5Fk/hqdefault.jpg",
  },
  {
    id: "d9",
    title: "I lost 20kg with this simple beginner gym split",
    channel: "Fit Basic",
    subs: 22000,
    views: 780000,
    avg: 64000,
    hours: 33,
    likes: 30000,
    comments: 1500,
    duration: 540,
    country: "US",
    cat: "헬스",
    thumb: "https://i.ytimg.com/vi/LXb3EKWsInQ/hqdefault.jpg",
  },
  {
    id: "d10",
    title: "쇼츠 자막 지우는 가장 쉬운 방법",
    channel: "Creator Fix",
    subs: 6800,
    views: 205000,
    avg: 11000,
    hours: 16,
    likes: 9900,
    comments: 420,
    duration: 380,
    country: "KR",
    cat: "AI 영상",
    thumb: "https://i.ytimg.com/vi/2Vv-BfVoq4g/hqdefault.jpg",
  },
];

function saveKey() {
  API = qs("#apiKey").value.trim();
  localStorage.setItem("vr_api_key", API);
  toast("API 키 저장됨");
}

function toggleDemo() {
  demo = !demo;
  localStorage.setItem("vr_demo", demo ? "on" : "off");
  updateDemoBtn();
  toast(demo ? "Demo ON" : "Demo OFF");
}

function updateDemoBtn() {
  setTimeout(() => {
    let b = qs("#demoBtn");
    if (b) b.textContent = demo ? "Demo ON" : "Demo OFF";
  }, 0);
}

function toast(t) {
  let el = qs("#toast");
  el.textContent = t;
  el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 1600);
}

function getMemo(id) {
  return JSON.parse(localStorage.getItem("vr_memo") || "{}")[id] || "";
}

function saveMemo(id, t) {
  let m = JSON.parse(localStorage.getItem("vr_memo") || "{}");
  m[id] = t;
  localStorage.setItem("vr_memo", JSON.stringify(m));
}
