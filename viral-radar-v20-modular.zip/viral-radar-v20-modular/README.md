# Viral Radar v20 Modular

기준: 사용자가 업로드한 실제 v12 프로젝트.

## 변경 내용

- CSS: `css/style.css` 유지
- JavaScript 기능별 분리
  - `data.js`: 탭 설정, 데모 데이터
  - `utils.js`: 공통 DOM/포맷/판정 함수
  - `storage.js`: localStorage, API 키, Demo 토글, Toast
  - `table.js`: 영상 테이블, 필터링, 인사이트
  - `drawer.js`: 상세 사이드 패널
  - `home.js`: 홈 대시보드
  - `search.js`: 검색 탭
  - `trend.js`: Hot Trend 탭
  - `channel.js`: 채널 분석 탭
  - `favorites.js`: 즐겨찾기, 가져오기/내보내기
  - `planner.js`: 기획 보드
  - `settings.js`: 설정/관심사 관리
  - `brief.js`: 쇼츠 제작안 생성기
  - `app.js`: 앱 부트스트랩, 탭 이동, 전체 렌더링

## 테스트 체크리스트

1. 홈 화면 카드/테이블 정상 표시
2. 검색 탭에서 키워드 검색
3. Hot Trend 탭 조회
4. 채널 분석 탭에서 `Dog Hero` 입력
5. 즐겨찾기 저장/해제
6. 기획 보드 추가
7. 제작안 생성
8. 설정에서 관심사 추가/삭제

정상 확인 후 커밋명:

```text
v20 - JS 기능별 모듈 분리
```
